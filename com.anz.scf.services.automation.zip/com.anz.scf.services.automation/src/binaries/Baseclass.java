package binaries;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import binaries.Datafetcher;
import binaries.configdataFetcher;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import sun.net.www.protocol.http.HttpURLConnection;

public class Baseclass {
	
	 public static HttpsURLConnection bypassSSL(String servicepath) throws NoSuchAlgorithmException, KeyManagementException, IOException, JSONException, MalformedURLException{
	        // configure the SSLContext with a TrustManager
	        SSLContext ctx = SSLContext.getInstance("TLS");
	        ctx.init(new KeyManager[0], new TrustManager[] {new DefaultTrustManager()}, new SecureRandom());
	        SSLContext.setDefault(ctx);

	        URL url = new URL(servicepath);
	        String host="http://gblproxyinch.service.anz";
			int port=9001;
			Proxy proxy = new Proxy(Proxy.Type.SOCKS, new InetSocketAddress(host, port));
	        
	        HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
	        conn.setHostnameVerifier(new HostnameVerifier() {
	            @Override
	            public boolean verify(String arg0, SSLSession arg1) {
	                return true;
	            }
	            
	            //Response s = RestAssured.get("https://bgteeserviceocr-mlaas.apps.cpaas.service.test/ocrNotification");
	            //HttpsURLConnection rest = (HttpsURLConnection) s.openConnection();
	        });
			return conn;
	        
	        
	       
}
	 
	 private static class DefaultTrustManager implements X509TrustManager {

	        @Override
	        public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {}

	        @Override
	        public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException {}

	        @Override
	        public X509Certificate[] getAcceptedIssuers() {
	            return null;
	        }
	    }

	public static StringBuffer bufferedreading(HttpsURLConnection url) throws IOException {
		
		 BufferedReader in = new BufferedReader(
                 new InputStreamReader(url.getInputStream()));
         String inputLine;
         StringBuffer response = new StringBuffer();
         while ((inputLine = in.readLine()) != null) {
        	 inputLine = inputLine.replace("[", "").replace("]", ""); 
        	 inputLine = inputLine.replaceAll("<.*?>|\u00a0", "");
         	response.append(inputLine);
         }
         in.close();
		
		return response;
		
		
	}
	 
}