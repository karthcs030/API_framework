package getPrioirtiy;

import java.io.File;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.json.JSONException;
 
/**
 * This program demonstrates a usage of the MultipartUtility class.
 * @author www.codejava.net
 *
 */
public class MultipartFileUploader {
 
    public static void main(String[] args) throws KeyManagementException, NoSuchAlgorithmException, JSONException {
        String charset = "UTF-8";
        File uploadFile = new File("C:\\NotBackedUp\\SCF_infoview.xlsx");
       //File uploadFile = new File("C:\\NotBackedUp\\21527339_CPIDED_1.pdf");
        
       // String requestURL = "https://mlaas-scf-services-orchestrator-mlaas-sit-scf.apps.cpaas.service.test/usecase/scf/orchestrator/invokeProcessInfoView";
       String requestURL2 = "https://mlaas-scf-services-document-mlaas-sit-scf.apps.cpaas.service.test/usecase/scf/document/addDocument";
       
        try {
            MultipartUtility multipart = new MultipartUtility(requestURL2, charset, uploadFile);
             
            multipart.addHeaderField("User-Agent", "CodeJava");
            multipart.addHeaderField("Authoriztion", "Bearer Welcome1");
            multipart.addHeaderField("Content-Type","application/vnd.ms-excel");
            //multipart.addHeaderField("Content-Type","application/pdf");
            //multipart.addFormField("description", "Cool Pictures");
            //multipart.addFormField("keywords", "Java,upload,Spring");
             
           multipart.addFilePart("file", uploadFile);
           // multipart.addFilePart("fileUpload", uploadFile2);
 
            List<String> response = multipart.finish();
             
            System.out.println("SERVER REPLIED:");
             
            for (String line : response) {
                System.out.println(line);
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }
}