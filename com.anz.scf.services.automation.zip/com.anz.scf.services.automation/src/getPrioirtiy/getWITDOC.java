package getPrioirtiy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.apache.tika.mime.MediaType;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import binaries.Baseclass;
import binaries.Datafetcher;
import binaries.configdataFetcher;
import io.restassured.internal.util.IOUtils;

public class getWITDOC {

	static configdataFetcher configdata;
	
	@DataProvider(name = "WIT_INFO", parallel = true)
	public Object[][] OrderAccountPagination() {
		String testDataPath = System.getProperty("user.dir")+"\\src\\binaries\\wit_details.xlsx";
		String sheetName = "Sheet3";
		return new Datafetcher(testDataPath).getDataFromXlsxtbySheetName(sheetName);
	}
	

	
	@Test(enabled=true, description = "Validate the WIT document")
	public static void getWitDoc() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		String servicepath = configdataFetcher.configData("getWITDoc");
		  String fileURL = "https://mlaas-scf-services-wit-mlaas-scf.apps.cpaas.service.test/api2/usecase/scf/wit/getWITDocs?witId=210643790005&docId=65";
	        String saveDir = "C:\\NotBackedUp\\downloads";
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("UI_token"));
	       // url.setRequestProperty("Content-Type", "application/json; utf-8");
	       // url.setDoOutput(true);       
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	       {
	         
	        	 String fileName = "";
	             String disposition = url.getHeaderField("Content-Disposition");
	             String contentType = url.getContentType();
	             int contentLength = url.getContentLength();
	  
	             if (disposition != null) {
	                 // extracts file name from header field
	                 int index = disposition.indexOf("filename=");
	                 if (index > 0) {
	                     fileName = disposition.substring(index + 10,
	                             disposition.length()-1);
	                 }
	             } else {
	                 // extracts file name from URL
	                 fileName = fileURL.substring(fileURL.lastIndexOf("/") + 1,
	                         fileURL.length());
	             }
	  
	             Reporter.log("Content-Type = " + contentType);
	             Reporter.log("Content-Disposition = " + disposition);
	             Reporter.log("Content-Length = " + contentLength);
	             Reporter.log("fileName = " + fileName);
	  
	             // opens input stream from the HTTP connection
	             InputStream inputStream = url.getInputStream();
	             String saveFilePath = saveDir + File.separator + fileName;
	              
	             // opens an output stream to save into file
	             FileOutputStream outputStream = new FileOutputStream(saveFilePath);
	  
	             int bytesRead = 0;
	             byte[] buffer = new byte[4096];
	             while ((bytesRead = inputStream.read(buffer)) != -1) {
	                 outputStream.write(buffer, 0, bytesRead);
	             }
	  
	             outputStream.close();
	             inputStream.close();
	  
	             Reporter.log("File downloaded");
	         } else {
	             Reporter.log("No file to download. Server replied HTTP code: " + url.getResponseCode());
	         }
	        // url.disconnect();
	     
	
	
	        Assert.assertEquals(n, 200);
	 }
	
	
	
	@Test(dataProvider="WIT_INFO",enabled=true, description = "Validate the WIT document")
	public static void getWitDoc_readfromexcel(String WIT_ID, String DOC_ID) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		String servicepath = configdataFetcher.configData("empty_getwitdoc")+WIT_ID+"&docId="+DOC_ID;
		  String fileURL = servicepath;
	        String saveDir = "C:\\NotBackedUp\\downloads";
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
	        url.setRequestProperty("Authorization", "Bearer Welcome1");
	       // url.setRequestProperty("Content-Type", "application/json; utf-8");
	       // url.setDoOutput(true);       
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	       {
	         
	        	 String fileName = "";
	             String disposition = url.getHeaderField("Content-Disposition");
	             String contentType = url.getContentType();
	             int contentLength = url.getContentLength();
	  
	             if (disposition != null) {
	                 // extracts file name from header field
	                 int index = disposition.indexOf("filename=");
	                 if (index > 0) {
	                     fileName = disposition.substring(index + 10,
	                             disposition.length()-1);
	                 }
	             } else {
	                 // extracts file name from URL
	                 fileName = fileURL.substring(fileURL.lastIndexOf("/") + 1,
	                         fileURL.length());
	             }
	  
	             Reporter.log("Content-Type = " + contentType);
	             Reporter.log("Content-Disposition = " + disposition);
	             Reporter.log("Content-Length = " + contentLength);
	            // Reporter.log("fileName = " + fileName);
	  
	             // opens input stream from the HTTP connection
	             InputStream inputStream = url.getInputStream();
	             String saveFilePath = saveDir + File.separator + fileName;
	              
	             // opens an output stream to save into file
	             FileOutputStream outputStream = new FileOutputStream(saveFilePath);
	  
	             int bytesRead = -1;
	             byte[] buffer = new byte[4096];
	             while ((bytesRead = inputStream.read(buffer)) != -1) {
	                 outputStream.write(buffer, 0, bytesRead);
	             }
	  
	             outputStream.close();
	             inputStream.close();
	  
	             Reporter.log("File downloaded");
	         } else {
	             Reporter.log("No file to download. Server replied HTTP code: " + url.getResponseCode());
	         }
	        // url.disconnect();
	     
	Assert.assertEquals(n, 200);
	
	
	 }

}