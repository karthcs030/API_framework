package getPrioirtiy;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.HttpsURLConnection;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import binaries.Baseclass;
import binaries.Datafetcher;
import binaries.configdataFetcher;

public class getRates {

	static configdataFetcher configdata;
	
	@DataProvider(name = "WIT_INFO", parallel = true)
	public Object[][] OrderAccountPagination() {
		String testDataPath = System.getProperty("user.dir")+"\\src\\binaries\\wit_details.xlsx";
		String sheetName = "Sheet8";
		return new Datafetcher(testDataPath).getDataFromXlsxtbySheetNamestring(sheetName);
	}

	
	
	@Test(dataProvider="WIT_INFO")
public static void getRates(String WIT_ID) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		
		Reporter.log("Passing WIT_ID's from Excel sheet");
		String servicepath = configdataFetcher.configData("getRates")+"2019-11-10&rate="+WIT_ID;//+"&rate="+Rate_type;
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
	        url.setRequestProperty("Authorization", "Bearer Welcome1");  
	        //url.setRequestProperty("witId", WIT_ID);
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	       {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");      
	        Reporter.log("rateType- "+myResponse.getString("rateType"));
	        Reporter.log("tenor- "+myResponse.getString("tenor"));
	       Reporter.log("rate- "+myResponse.getString("rate"));           
	       
		
		
		
	}
	             	
	        Assert.assertEquals(n, 200);
	}
}