package getPrioirtiy;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import binaries.Baseclass;
import binaries.Datafetcher;
import binaries.configdataFetcher;

public class getUpdateDoc {
	
static configdataFetcher configdata;
	
	@DataProvider(name = "WIT_INFO", parallel = true)
	public Object[][] OrderAccountPagination() {
		String testDataPath = System.getProperty("user.dir")+"\\src\\binaries\\wit_details.xlsx";
		String sheetName = "Sheet1";
		return new Datafetcher(testDataPath).getDataFromXlsxtbySheetName(sheetName);
	}
	
	
@Test (description="Validate Service updateDocStatus", enabled=true, dataProvider="WIT_INFO")
	
	public static void getUpdatedoc(String WIT_ID) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		String servicepath = configdataFetcher.configData("update_doc");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("POST");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("RPA_token"));
	        url.setRequestProperty("Content-Type", "application/json; utf-8");
	        url.setDoOutput(true);
	        
	        OutputStream os = url.getOutputStream();
	        OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");    
	        osw.write("{\"witId\":\""
	        		+ WIT_ID
	        				+ "\",\"status\":\"Completed\",\"totalNoOfDocs\":\"2\",\"statusMsg\":\"Successful\"}");
	        osw.flush();
	        osw.close();
	        os.close(); 
	        
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response Code found for service"+n);
	       if(n==200)
	        {
	         
	    	   StringBuffer response = Baseclass.bufferedreading(url);
	         //print in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");
	       
	        Reporter.log("module- "+myResponse.getString("module"));
	        Reporter.log("message- "+myResponse.getString("message"));
	        
	        
		
		
		
	}
	       Assert.assertEquals(n, 200);
	
}


}
