package getPrioirtiy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.apache.tika.mime.MediaType;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import binaries.Baseclass;
import binaries.Datafetcher;
import binaries.configdataFetcher;
import io.restassured.internal.util.IOUtils;

public class invokeocr {

	static configdataFetcher configdata;
	
	 @DataProvider(name = "WIT_INFO", parallel = true)
		public Object[][] OrderAccountPagination() {
			String testDataPath = System.getProperty("user.dir")+"\\src\\binaries\\wit_details.xlsx";
			String sheetName = "Sheet1";
			return new Datafetcher(testDataPath).getDataFromXlsxtbySheetName(sheetName);
		}

	
	
	@Test (description="Validate Service InvokeOCR", enabled=true)

	public static void invokeOCR() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		String servicepath = configdataFetcher.configData("invoke_ocr");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("UI_token"));
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	        {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         //JSONObject myResponse = new JSONObject(response.toString());
	       // Reporter.log("Results after Reading JSON Response");
	       // Reporter.log("statusCode- "+myResponse.getString("statusCode"));
	        //Reporter.log("statusMessage- "+myResponse.getString("statusMessage"));
	        //Reporter.log("ipAddress- "+myResponse.getString("ipAddress"));
	       // Reporter.log("Status- "+myResponse.getString("status"));
	       // Reporter.log("message- "+myResponse.getString("message"));
	        
	        
		
		
		
	}

	        Assert.assertEquals(n, 200);
	}

	@Test (description="Validate Service InvokeOCR", enabled=true)

	public static void invokeOCR_min() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		String servicepath = configdataFetcher.configData("invoke_ocr2");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
	        url.setRequestProperty("Authorization", "Bearer Perftest019!test.com");
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	        {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         //JSONObject myResponse = new JSONObject(response.toString());
	        //Reporter.log("Results after Reading JSON Response");
	       // Reporter.log("statusCode- "+myResponse.getString("statusCode"));
	        //Reporter.log("statusMessage- "+myResponse.getString("statusMessage"));
	        //Reporter.log("ipAddress- "+myResponse.getString("ipAddress"));
	       // Reporter.log("Status- "+myResponse.getString("status"));
	       // Reporter.log("message- "+myResponse.getString("message"));
	        
	        
		
		
		
	}

	        Assert.assertEquals(n, 200);
	}
	
	@Test (description="Validate Service InvokeOCR", enabled=true)

	public static void invokeOCR_invalid() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		String servicepath = configdataFetcher.configData("invoke_ocr_invalid");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
	        url.setRequestProperty("Authorization", "Bearer Perftest019!test.com");
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	        {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");
	       // Reporter.log("statusCode- "+myResponse.getString("statusCode"));
	        //Reporter.log("statusMessage- "+myResponse.getString("statusMessage"));
	        //Reporter.log("ipAddress- "+myResponse.getString("ipAddress"));
	       // Reporter.log("Status- "+myResponse.getString("status"));
	        Reporter.log("message- "+myResponse.getString("message"));
	        
	        
		
		
		
	}

	        Assert.assertEquals(n, 200);
	}
	
	@Test (description="Validate Service InvokeOCR", enabled=true)

	public static void invokeOCR_docdownload() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		Reporter.log("Looking for Document_Download Status in response");
		String servicepath = configdataFetcher.configData("invoke_ocr_doc_download");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
	        url.setRequestProperty("Authorization", "Bearer Perftest019!test.com");
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	        {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");
	       // Reporter.log("statusCode- "+myResponse.getString("statusCode"));
	        //Reporter.log("statusMessage- "+myResponse.getString("statusMessage"));
	        //Reporter.log("ipAddress- "+myResponse.getString("ipAddress"));
	       // Reporter.log("Status- "+myResponse.getString("status"));
	        Reporter.log("message- "+myResponse.getString("message"));
	        
	        
		
		
		
	}

	        Assert.assertEquals(n, 200);
	}
	
	@Test (description="Validate Service InvokeOCR", enabled=true)

	public static void invokeOCR_null() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		
		Reporter.log("Passing Empty string as a WIT_IDas a parameter");
		String servicepath = configdataFetcher.configData("invoke_ocr_doc_null");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
	        url.setRequestProperty("Authorization", "Bearer Perftest019!test.com");
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	        {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");
	       // Reporter.log("statusCode- "+myResponse.getString("statusCode"));
	        //Reporter.log("statusMessage- "+myResponse.getString("statusMessage"));
	        //Reporter.log("ipAddress- "+myResponse.getString("ipAddress"));
	       // Reporter.log("Status- "+myResponse.getString("status"));
	        Reporter.log("message- "+myResponse.getString("message"));
	        
	        
		
		
		
	}

	        Assert.assertEquals(n, 200);
	}
	
	@Test (description="Validate Service InvokeOCR", enabled=true)

	public static void invokeOCR_newdoc() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		
		Reporter.log("Passing Empty string as a WIT_IDas a parameter");
		String servicepath = configdataFetcher.configData("invoke_ocr_newdoc");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
	        url.setRequestProperty("Authorization", "Bearer Perftest019!test.com");
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	        {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         //JSONObject myResponse = new JSONObject(response.toString());
	        //Reporter.log("Results after Reading JSON Response");
	       // Reporter.log("statusCode- "+myResponse.getString("statusCode"));
	        //Reporter.log("statusMessage- "+myResponse.getString("statusMessage"));
	        //Reporter.log("ipAddress- "+myResponse.getString("ipAddress"));
	       // Reporter.log("Status- "+myResponse.getString("status"));
	        //Reporter.log("message- "+myResponse.getString("message"));
	        
	        
		
		
		
	}

	        Assert.assertEquals(n, 200);
	}

	@Test (description="Validate Service InvokeOCR", enabled=true)

	public static void invokeOCR_MLcompelted() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		
		Reporter.log("Passing Empty string as a WIT_IDas a parameter");
		String servicepath = configdataFetcher.configData("invoke_ocr_ML1Completed");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
	        url.setRequestProperty("Authorization", "Bearer Perftest019!test.com");
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	        {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	        // JSONObject myResponse = new JSONObject(response.toString());
	        //Reporter.log("Results after Reading JSON Response");
	       // Reporter.log("statusCode- "+myResponse.getString("statusCode"));
	        //Reporter.log("statusMessage- "+myResponse.getString("statusMessage"));
	        //Reporter.log("ipAddress- "+myResponse.getString("ipAddress"));
	       // Reporter.log("Status- "+myResponse.getString("status"));
	        //Reporter.log("message- "+myResponse.getString("message"));
	        
	        
		
		
		
	}

	        Assert.assertEquals(n, 200);
	}
	
	@Test (description="Validate Service InvokeOCR", enabled=true)

	public static void invokeOCR_maxlength() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		
		Reporter.log("Passing 19 digits as WIT_ID parameter");
		String servicepath = configdataFetcher.configData("invoke_ocr_ML1Completed");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
	        url.setRequestProperty("Authorization", "Bearer Perftest019!test.com");
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	        {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         //JSONObject myResponse = new JSONObject(response.toString());
	        //Reporter.log("Results after Reading JSON Response");
	       // Reporter.log("statusCode- "+myResponse.getString("statusCode"));
	        //Reporter.log("statusMessage- "+myResponse.getString("statusMessage"));
	        //Reporter.log("ipAddress- "+myResponse.getString("ipAddress"));
	       // Reporter.log("Status- "+myResponse.getString("status"));
	        //Reporter.log("message- "+myResponse.getString("message"));
	        
	        
		
		
		
	}

	        Assert.assertEquals(n, 200);
	}
	
	@Test (dataProvider="WIT_INFO", description="readatafromexcel", enabled=true)

	public static void invokeOCR_readfromexcel(String WIT_ID) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		
		Reporter.log("Passing WIT_ID's from Excel sheet");
		String servicepath = configdataFetcher.configData("emptyurl")+WIT_ID;
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
	        url.setRequestProperty("Authorization", "Bearer Perftest019!test.com");
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	        {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         //JSONObject myResponse = new JSONObject(response.toString());
	        //Reporter.log("Results after Reading JSON Response");
	       // Reporter.log("statusCode- "+myResponse.getString("statusCode"));
	        //Reporter.log("statusMessage- "+myResponse.getString("statusMessage"));
	        //Reporter.log("ipAddress- "+myResponse.getString("ipAddress"));
	       // Reporter.log("Status- "+myResponse.getString("status"));
	        //Reporter.log("message- "+myResponse.getString("message"));
	        
	        
		
		
		
	}

	        Assert.assertEquals(n, 200);
	}

}