package getPrioirtiy;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.HttpsURLConnection;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import binaries.Baseclass;
import binaries.Datafetcher;
import binaries.configdataFetcher;

public class updateWitComments {

	static configdataFetcher configdata;
	
	@DataProvider(name = "WIT_INFO", parallel = true)
	public Object[][] OrderAccountPagination() {
		String testDataPath = System.getProperty("user.dir")+"\\src\\binaries\\wit_details.xlsx";
		String sheetName = "Sheet9";
		return new Datafetcher(testDataPath).getDataFromXlsxtbySheetName(sheetName);
	}

	@Test(dataProvider="WIT_INFO")
	//@Test
	public static void updatecomments(String WIT_ID, String Customer_ID) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		
		Reporter.log("Passing WIT_ID's from Excel sheet");
		String servicepath = configdataFetcher.configData("update_wit_comments");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("POST");
	        url.setRequestProperty("Authorization", configdataFetcher.configData("RPA_token"));           
	       
	        url.setRequestProperty("Content-Type", "application/json; utf-8");
	        url.setDoOutput(true);
	        
	        OutputStream os = url.getOutputStream();
	        OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");    
	        osw.write("{\r\n\t\"witId\" : "
	        		+ WIT_ID
	        		+",\r\n    \"witComments\"  : \"sucessfully uploaded WITcomments - RPA3\",\r\n     \"discrepancy\"  : \"N\"\r\n     \r\n\t\r\n} ");
	        osw.flush();
	        osw.close();
	        os.close(); 
	        
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response Code found for service"+n);
	       if(n==200)
	        {
	         
	    	   StringBuffer response = Baseclass.bufferedreading(url);
	         //print in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");
	       
	        Reporter.log("module- "+myResponse.getString("module"));
	        Reporter.log("message- "+myResponse.getString("message"));
		
	}
	             	
	        Assert.assertEquals(n, 200);
	}
}
