package getPrioirtiy;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONException;
import org.testng.annotations.Test;

import binaries.Baseclass;
import binaries.configdataFetcher;

public class uploadfile {


	@Test
	
	
	public static void infoviewreport() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		String servicepath = configdataFetcher.configData("invoke_infoview");
		HttpsURLConnection urlConn = Baseclass.bypassSSL(servicepath);
	
	
	 urlConn.setRequestMethod("POST");
	    //urlConn.setRequestProperty("X-Method-Override", "PUT");     
	    urlConn.setRequestProperty("Content-Type", "multipart/form-data"); 
	    urlConn.setRequestProperty("Authorization", "Bearer welcome1");
	    urlConn.setUseCaches(false);
	    urlConn.setDoInput(true);
	    urlConn.setDoOutput(true);
	    HttpURLConnection.setFollowRedirects(false);
	    urlConn.setRequestProperty("file", "C:\\NotBackedUp\\SCF_infoview.xlsx"); 
	    String write = readFile("C:\\NotBackedUp\\SCF_infoview.xlsx");
	    urlConn.setRequestProperty("Content-Length","" + write.length());
	    urlConn.getOutputStream().write(write.getBytes("UTF8"));
	    System.out.println(urlConn.getResponseCode());
	
}

	private static String readFile(String test) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(test));
	    String line = null;
	    StringBuilder stringBuilder = new StringBuilder();
	    String ls = System.getProperty("line.separator");

	    while ((line = reader.readLine()) != null) {
	        stringBuilder.append(line);
	        stringBuilder.append(ls);
	    }
	    reader.close();
	    return stringBuilder.toString();
	    
	}
}
