package getPrioirtiy;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
//import java.util.Base64;

import javax.net.ssl.HttpsURLConnection;

//import org.apache.xmlbeans.impl.util.Base64;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.apache.commons.codec.binary.Base64;

//import com.sun.org.apache.xml.internal.security.utils.Base64;

//import com.sun.xml.internal.messaging.saaj.util.Base64;

//import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

import binaries.Baseclass;
import binaries.Datafetcher;
import binaries.configdataFetcher;

public class generateToken {

	static configdataFetcher configdata;
	
	@DataProvider(name = "WIT_INFO", parallel = true)
	public Object[][] OrderAccountPagination() {
		String testDataPath = System.getProperty("user.dir")+"\\src\\binaries\\wit_details.xlsx";
		String sheetName = "Sheet8";
		return new Datafetcher(testDataPath).getDataFromXlsxtbySheetNamestring(sheetName);
	}

	
	
	@Test
public static void generateToken() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException, InterruptedException {
		
		String username ="9f2ca23f-5979-4866-b02e-f2206aa95536";
        String password = "c79c0720871d4998b0d6a17b04347c5a";

        String conn = "https://auth.service.dev/oidc/authorize";
      
        String auth = username + ":" + password;
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.UTF_8));
        String authHeaderValue = new String(encodedAuth);
        System.out.println("Auth Code encoded"+encodedAuth);
        
		Reporter.log("Passing WIT_ID's from Excel sheet");
		String host="http://gblproxyinch.service.anz";
		int port=9001;
		Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(host, port));
		String servicepath = configdataFetcher.configData("authgenerator");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		url.setConnectTimeout(25000);
		url.setReadTimeout(25000);
		//HttpsURLConnection conn = (HttpsURLConnection) new URL(url).openConnection(proxy);
		//url.setRequestMethod("POST");
        url.setRequestProperty("Authorization", "Basic OWYyY2EyM2YtNTk3OS00ODY2LWIwMmUtZjIyMDZhYTk1NTM2OmM3OWMwNzIwODcxZDQ5OThiMGQ2YTE3YjA0MzQ3YzVh");  
        url.usingProxy();
       
        url.setRequestProperty("Content-Type", "application/json; utf-8");
        //url.set
        url.setDoOutput(true);
        //Thread.sleep(15000);
        OutputStream os = url.getOutputStream();
        OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");    
        osw.write("{\r\n" + 
        		"\"grant_type\": \"password\",\r\n" + 
        		"\"username\": \"aumlsscfdbdsa@GLOBALTEST.ANZ.COM\",\r\n" + 
        		"\"password\": \"Ev*luti*n0456789\",\r\n" + 
        		"\"response_type\": \"token id_token\",\r\n" + 
        		"\"client_id\": \"67ac1b8e-3df6-4575-a5bf-3cc313d13c3d\",\r\n" + 
        		"\"scope\": \"openid \"\r\n" + 
        		"}\r\n" + 
        		"");
        osw.flush();
        osw.close();
        os.close(); 
        //Thread.sleep(15000);
       
        int n = url.getResponseCode();
        System.out.println("Response Code found for service"+n);
        Reporter.log("Response Code found for service"+n);
       if(n==200)
        {
         
    	   StringBuffer response = Baseclass.bufferedreading(url);
         //print in String
        Reporter.log(response.toString());
         //Read JSON response and print
         JSONObject myResponse = new JSONObject(response.toString());
        Reporter.log("Results after Reading JSON Response");
       
        Reporter.log("module- "+myResponse.getString("module"));
        Reporter.log("message- "+myResponse.getString("message"));
	
}
             	
        Assert.assertEquals(n, 200);
}
}