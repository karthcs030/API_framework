package getPrioirtiy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.apache.tika.mime.MediaType;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import binaries.Baseclass;
import binaries.Datafetcher;
import binaries.configdataFetcher;
import io.restassured.internal.util.IOUtils;

public class getWitbyPriority {

	static configdataFetcher configdata;
	
	
		@DataProvider(name = "WIT_INFO", parallel = true)
		public Object[][] OrderAccountPagination() {
			String testDataPath = "C:\\NotBackedUp\\project_code\\HybridFramework-master\\HybridFramework-master\\Hybridframework\\Hybridframework\\Design\\Wit_info.xlsx";
			String sheetName = "Sheet2";
			return new Datafetcher(testDataPath).getDataFromXlsxtbySheetName(sheetName);
		}
	
	
	@Test (description="Validate Service getwitBYPriority", enabled=true)
	
	public static void getwitPriority() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		String servicepath = configdataFetcher.configData("BGteeurl");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
	        url.setRequestProperty("Authorization", "Bearer Perftest019!test.com");
	        int n = url.getResponseCode();
	        Reporter.log("Response code found is" +n);
	
	        if(n==200)
	        {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");
	       // Reporter.log("statusCode- "+myResponse.getString("statusCode"));
	        //Reporter.log("statusMessage- "+myResponse.getString("statusMessage"));
	        //Reporter.log("ipAddress- "+myResponse.getString("ipAddress"));
	        Reporter.log("priorityType- "+myResponse.getString("priorityType"));
	        Reporter.log("customerId- "+myResponse.getString("customerId"));
	        
	        
		
		
		
	}
	        Assert.assertEquals(n, 200);
}
	
@Test (description="Validate Service updateDocStatus", enabled=true,dataProvider="WIT_INFO")
	
	public static void getUpdatedoc(String WIT_ID) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		String servicepath = configdataFetcher.configData("update_doc");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("POST");
	        url.setRequestProperty("Authorization", "Bearer Perftest019!test.com");
	        url.setRequestProperty("Content-Type", "application/json; utf-8");
	        url.setDoOutput(true);
	        
	        OutputStream os = url.getOutputStream();
	        OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");    
	        osw.write("{\"witId\":\2234379600\",\"status\":\"Completed\",\"totalNoOfDocs\":\"2\",\"statusMsg\":\"Successful\"}");
	        osw.flush();
	        osw.close();
	        os.close(); 
	        
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response Code found for service"+n);
	       if(n==200)
	        {
	         
	    	   StringBuffer response = Baseclass.bufferedreading(url);
	         //print in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");
	       
	        Reporter.log("module- "+myResponse.getString("module"));
	        Reporter.log("message- "+myResponse.getString("message"));
	        
	        
		
		
		
	}
	       Assert.assertEquals(n, 200);
	
}


@Test (description="Validate Service InvokeProcessInfoview", enabled=true)

public static <RequestBody> void getAdddoc() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
	
	String servicepath = configdataFetcher.configData("invoke_infoview");
	HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
	 url.setRequestMethod("GET");
        url.setRequestProperty("Authorization", "Perftest019!test.com");
        
        String boundaryString = "----SomeRandomText";
        
     // Indicate that we want to write to the HTTP request body
             url.setDoOutput(true);
             //url.setRequestMethod("POST");
             url.setRequestProperty("Authorization", "Welcome1");
          	 url.setRequestProperty("File", "binary");
             url.addRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundaryString);
        
        
          // Indicate that we want to write some data as the HTTP request body
             url.setDoOutput(true);
             OutputStream outputStreamToRequestBody = url.getOutputStream();
             BufferedWriter httpRequestBodyWriter =
                     new BufferedWriter(new OutputStreamWriter(outputStreamToRequestBody));
          // Include value from the myFileDescription text area in the post data
             httpRequestBodyWriter.write("\n\n--" + boundaryString + "\n");
             httpRequestBodyWriter.write("Content-Disposition: form-data");
             httpRequestBodyWriter.write("Content-Type: application/json");
            
             httpRequestBodyWriter.write("Content-Disposition: form-data;"
            		 +"name=\"file\";"
            		 +"filename=\"C:\\NotBackedUp\\SCF_Framework\\framework\\src\\test\\resources\\binaries\\Work_Group_Open_Items_-_SCF1.xlsx"
                    
                     + "\nContent-Type: application/vnd.ms-excel\n\n");
        
        
        
             httpRequestBodyWriter.flush();
             
          // Mark the end of the multipart http request
                  httpRequestBodyWriter.write("\n--" + boundaryString + "--\n");
                  httpRequestBodyWriter.flush();
           
          // Close the streams
                  int n = url.getResponseCode();
                  if (n==500) {
                  outputStreamToRequestBody.close();
                  httpRequestBodyWriter.close();
                  BufferedReader in = new BufferedReader(
                          new InputStreamReader(url.getInputStream()));
                  String inputLine;
                  StringBuffer response = new StringBuffer();
                  while ((inputLine = in.readLine()) != null) {
                      response.append(inputLine);
                  }
                  in.close();
                  //print result
           
                  System.out.println(response.toString());
        
        
        //All tried methods so far 
        //url.setRequestProperty("Content-Type", "application/json; utf-8");
       // url.setDoOutput(true);
        
        //MediaType mediaType = MediaType.parse("multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW");
    	//url.setRequestProperty("multipart/form-data", "WebKitFormBoundary7MA4YWxkTrZu0gW\r\nContent-Disposition: form-data; name=\"file\"; filename=\"C:\\Users\\lakshmk6\\AppData\\Roaming\\Postman\\IndexedDB\\file__0.indexeddb.blob\\1\\00\\5\"\r\nContent-Type: false\r\n\r\n\r\n------WebKitFormBoundary7MA4YWxkTrZu0gW--");
        
       // OutputStream outputStream =  url.getOutputStream();
        //outputStream.write("file=".getBytes());
        /*url.setRequestProperty("content-type", "multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW");
  	  url.setRequestProperty("Authorization", "Welcome1");
  	 // url.setRequestProperty("File", "binary");
  	url.setRequestProperty("content-type", "application/vnd.ms-excel");*/
  	 
     Reporter.log("Response code for Service:"+n);
     
     
    	 Reporter.log("Sucess!!! document is added");
     }
     else {
     	Map<String, List<String>> s = url.getHeaderFields();
     	InputStream _is;
     	
     	    _is = url.getErrorStream();
     	    //Object errorreponse = url.getInputStream();
     	    Reporter.log("Error found while hitting API"+_is);
     	    Reporter.log("Header values found"+s);
     	    //Reporter.log("Error content"+errorreponse);
     	}
                //byte[] buffer contains the data
          /*  outputStream.write(buffer);         
        outputStream.close();
        
        //url.setRequestProperty("Content-Type", "audio/x-flac; rate=16000");
        String parameterString = "file=" + url.get("C:\\NotBackedUp\\SCF_Framework\\framework\\src\\test\\resources\\binaries\\Work_Group_Open_Items_-_SCF1.xlsx");
        outputStream.write(url.getBytes("UTF-8"); //Don't forget, HTTP protocol supports UTF-8 encoding.
        outputStream.flush();*/
	Assert.assertEquals(n, 200);
	
	
}

@Test (description="Validate Service InvokeOCR", enabled=true)

public static void invokeOCR() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
	
	String servicepath = configdataFetcher.configData("invoke_ocr");
	HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
	 url.setRequestMethod("GET");
	 url.setRequestProperty("Authorization", configdataFetcher.configData("RPA_token"));
        int n = url.getResponseCode();
        Reporter.log("Response code for Service:"+n);
        if(n==200)
        {
         
        	BufferedReader in = new BufferedReader(
                    new InputStreamReader(url.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
           	inputLine = inputLine.replace("[", "").replace("]", ""); 
           	// inputLine = inputLine.replaceAll("<.*?>|\u00a0", "");
            	response.append(inputLine);
            	Reporter.log(response.toString());
         /*JSONObject myResponse = new JSONObject(response.toString());
        Reporter.log("Results after Reading JSON Response");      
        Reporter.log("OperORG- "+myResponse.getString("operORG")); */
        
            }
	
	
	
}

        Assert.assertEquals(n, 200);
}

@Test
public static void uisummary() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
	
	String servicepath = configdataFetcher.configData("ui_summary");
	HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
	 url.setRequestMethod("GET");
        url.setRequestProperty("Authorization", "Bearer Welcome1");
        url.setRequestProperty("Content-Type", "application/json; utf-8");
        url.setDoOutput(true);       
       
        int n = url.getResponseCode();
        Reporter.log("Response code for Service:"+n);
        if(n==200)
       {
         
        	StringBuffer response = Baseclass.bufferedreading(url);
         //print entire service response in String
        Reporter.log(response.toString());
         //Read JSON response and print
         JSONObject myResponse = new JSONObject(response.toString());
        Reporter.log("Results after Reading JSON Response");      
        Reporter.log("OperORG- "+myResponse.getString("operORG")); 
        Reporter.log("Customer Names- "+myResponse.getString("customer")); 
        Reporter.log("Priority- "+myResponse.getString("priority")); 
        
     
       
	
	
}
       
        	
       
        Assert.assertEquals(n, 200);
}

@Test(enabled=false, description = "Validate the WIT document")
public static void getWitDoc() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
	
	String servicepath = configdataFetcher.configData("getWITDoc");
	HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
	 url.setRequestMethod("GET");
        url.setRequestProperty("Authorization", "Bearer Welcome1");
       // url.setRequestProperty("Content-Type", "application/json; utf-8");
       // url.setDoOutput(true);       
       
        int n = url.getResponseCode();
        Reporter.log("Response code for Service:"+n);
        if(n==200)
       {
        	BufferedReader in = new BufferedReader(
                    new InputStreamReader(url.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
           	inputLine = inputLine.replace("[", "").replace("]", ""); 
           	 inputLine = inputLine.replaceAll("<.*?>|\u00a0", "");
            	response.append(inputLine);
         JSONObject myResponse = new JSONObject(response.toString());
        Reporter.log("Results after Reading JSON Response");      
        Reporter.log("OperORG- "+myResponse.getString("operORG"));    
	
}
       }
        else {
        	Map<String, List<String>> s = url.getHeaderFields();
        	InputStream _is;
        	
        	    _is = url.getErrorStream();
        	    //Object errorreponse = url.getInputStream();
        	    Reporter.log("Error found while hitting API"+_is);
        	    Reporter.log("Header values found"+s);
        	    //Reporter.log("Error content"+errorreponse);
        	}
        
             	
        Assert.assertEquals(n, 200);
}


@Test(enabled=true, description="Verify Document details for a WIT")
public static void getWitDetails() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
	
	String servicepath = configdataFetcher.configData("wit_entities");
	HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
	 url.setRequestMethod("GET");
        url.setRequestProperty("Authorization", "Bearer Welcome1");
        url.setRequestProperty("Accept", "application/json");
       // url.setRequestProperty("Content-Type", "application/json; utf-8");
       // url.setDoOutput(true);       
       
        int n = url.getResponseCode();
        Reporter.log("Response code for Service:"+n);
        //Reporter.log("Json body found for the service"+url.getContent());
        if(n==200)
       {
         

        	 BufferedReader in = new BufferedReader(
                     new InputStreamReader(url.getInputStream()));
             String inputLine;
             StringBuffer response = new StringBuffer();
             while ((inputLine = in.readLine()) != null) {
            	inputLine = inputLine.replace("[", "").replace("]", ""); 
            	 inputLine = inputLine.replaceAll("<.*?>|\u00a0", "");
             	response.append(inputLine);
             }
             in.close();
         //print entire service response in String
        Reporter.log(response.toString());
         //Read JSON response and print
         JSONObject myResponse = new JSONObject(response.toString());
        Reporter.log("Results after Reading JSON Response");      
        Reporter.log("isMakerStarted- "+myResponse.getString("isMakerStarted"));
        Reporter.log("WitId- "+myResponse.getString("WitId"));
        Reporter.log("userId- "+myResponse.getString("userId"));        
       
	
	
	
}
             	
        Assert.assertEquals(n, 200);
}

@Test(enabled=true, description="Verify Document details for a WIT")
public static void getWitDetails_valid() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
	
	String servicepath = configdataFetcher.configData("wit_entities_valid");
	HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
	 url.setRequestMethod("GET");
        url.setRequestProperty("Authorization", "Bearer Welcome1");
        url.setRequestProperty("Accept", "application/json");
       // url.setRequestProperty("Content-Type", "application/json; utf-8");
       // url.setDoOutput(true);       
       
        int n = url.getResponseCode();
        Reporter.log("Response code for Service:"+n);
        //Reporter.log("Json body found for the service"+url.getContent());
        if(n==200)
       {
         

        	 BufferedReader in = new BufferedReader(
                     new InputStreamReader(url.getInputStream()));
             String inputLine;
             StringBuffer response = new StringBuffer();
             while ((inputLine = in.readLine()) != null) {
            	inputLine = inputLine.replace("[", "").replace("]", ""); 
            	 inputLine = inputLine.replaceAll("<.*?>|\u00a0", "");
             	response.append(inputLine);
             }
             in.close();
         //print entire service response in String
        Reporter.log(response.toString());
         //Read JSON response and print
        /* JSONObject myResponse = new JSONObject(response.toString());
        Reporter.log("Results after Reading JSON Response");      
        Reporter.log("isMakerStarted- "+myResponse.getString("isMakerStarted"));
        Reporter.log("WitId- "+myResponse.getString("WitId"));
        Reporter.log("userId- "+myResponse.getString("userId"));   */     
       
	
	
	
}
             	
        Assert.assertEquals(n, 200);
}



}


	
	
	
	
	
