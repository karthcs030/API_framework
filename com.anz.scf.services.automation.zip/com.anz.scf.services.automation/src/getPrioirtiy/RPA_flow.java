package getPrioirtiy;

import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import binaries.Baseclass;
import binaries.Datafetcher;
import binaries.configdataFetcher;

public class RPA_flow {

	static configdataFetcher configdata;

	@DataProvider(name = "WIT_INFO", parallel = true)
	public static Object[][] OrderAccountPagination() {
		String testDataPath = System.getProperty("user.dir")+"\\src\\binaries\\wit_details.xlsx";
		String sheetName = "Sheet9";
		new Datafetcher(testDataPath);
		return Datafetcher.getDataFromXlsxtbySheetName(sheetName);
	}
	
	@DataProvider(name = "SKIP_OCR", parallel = true)
	public Object[][] customerID() {
		String testDataPath = System.getProperty("user.dir")+"\\src\\binaries\\wit_details.xlsx";
		String sheetName = "Sheet10";
		new Datafetcher(testDataPath);
		return Datafetcher.getDataFromXlsxtbySheetName(sheetName);
	}

	@Test(priority=0, enabled=true)

	public static void invoke_infoview() throws KeyManagementException, NoSuchAlgorithmException, JSONException {
		String WIT_ID="";
		String charset = "UTF-8";
		System.out.println("Invoking as service invoke Infoview");
		File uploadFile = new File("C:\\NotBackedUp\\RPA_Files\\SCF_infoview.xlsx");
		//File uploadFile = new File("C:\\NotBackedUp\\21527339_CPIDED_1.pdf");

		String requestURL = configdataFetcher.configData("invoke_infoview");
		//String requestURL2 = "https://mlaas-scf-services-document-mlaas-sit-scf.apps.cpaas.service.test/usecase/scf/document/addDocument";

		try {
			MultipartUtility multipart = new MultipartUtility(requestURL, charset, uploadFile, WIT_ID);

			multipart.addHeaderField("User-Agent", "CodeJava");
			multipart.addHeaderField("Authoriztion", configdataFetcher.configData("RPA_token"));
			multipart.addHeaderField("Content-Type","application/vnd.ms-excel");
			//multipart.addHeaderField("Content-Type","application/pdf");
			//multipart.addFormField("description", "Cool Pictures");
			//multipart.addFormField("keywords", "Java,upload,Spring");

			multipart.addFilePart("file", uploadFile);
			// multipart.addFilePart("fileUpload", uploadFile2);
			System.out.println("Invoke sucessful. Infoview file status awaited.");

			List<String> response = multipart.finish();

			System.out.println("SERVER REPLIED:");

			for (String line : response) {
				System.out.println(line);
			}
		} catch (IOException ex) {
			System.out.println(ex.toString());
			
		}
	}

	@Test(priority = 1, dataProvider="WIT_INFO", enabled=true, dependsOnMethods={"invoke_infoview"})
	//@Test
	public static void setpartydetails(String WIT_ID, String Customer_ID) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException, InterruptedException {

		//Thread.sleep(5000);
		System.out.println("Invoking as service setPartyDetails");
		String servicepath = configdataFetcher.configData("Setpartydetails");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		url.setRequestMethod("POST");
		url.setRequestProperty("Authorization", configdataFetcher.configData("RPA_token"));          

		url.setRequestProperty("Content-Type", "application/json; utf-8");
		url.setDoOutput(true);

		OutputStream os = url.getOutputStream();
		OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");    
		osw.write("{\r\n" + 
				"	\"workItemNum\":"
				+ WIT_ID
				+ ", \r\n" + 
				"	\"buyerId\":\"VILLA-WOOLWORTHS-RF\",\r\n" + 
				"	\"buyerName\":\"WOOLWORTHS LTD\",\r\n" + 
				"	\"sellerId\":\"VILLAMARIA\",\r\n" + 
				"	\"sellerName\":\"Villa Maria Wine Estate Pty Ltd\"\r\n" + 
				"	\r\n" + 
				"}");
		osw.flush();
		osw.close();
		os.close(); 

		System.out.println("Invoking sucess. Awaiting response");
		int n = url.getResponseCode();
		System.out.println("Response Code found for service"+n);
		if(n==404) {
			setpartydetails(WIT_ID, Customer_ID);
			System.out.println("404 found. Retrying a service");
		}
		if(n==200)
		{

			StringBuffer response = Baseclass.bufferedreading(url);
			//print in String
			System.out.println(response.toString());
			//Read JSON response and print
			JSONObject myResponse = new JSONObject(response.toString());
			System.out.println("Results after Reading JSON Response");

			System.out.println("module- "+myResponse.getString("module"));
			System.out.println("message- "+myResponse.getString("message"));

		}

		Assert.assertEquals(n, 200);
	}

	@Test (priority = 2,enabled=true, dataProvider="WIT_INFO")
	public static void setinvoice(String WIT_ID, String Customer_ID) throws KeyManagementException, NoSuchAlgorithmException, JSONException, InterruptedException {

		Thread.sleep(5000);
		String charset = "UTF-8";
		System.out.println("Invoking as service setInvoiceDetails");
		File uploadFile = new File("C:\\NotBackedUp\\RPA_Files\\"+WIT_ID+"_Finance_1.csv");
		//File uploadFile = new File("C:\\NotBackedUp\\21527339_CPIDED_1.pdf");

		String requestURL = configdataFetcher.configData("setinvoice");
		//String requestURL2 = "https://mlaas-scf-services-document-mlaas-sit-scf.apps.cpaas.service.test/usecase/scf/document/addDocument";

		try {
			MultipartUtility multipart = new MultipartUtility(requestURL, charset, uploadFile, WIT_ID);

			multipart.addHeaderField("User-Agent", "CodeJava");
			multipart.addHeaderField("Authoriztion", configdataFetcher.configData("RPA_token"));
			multipart.addHeaderField("Content-Type","application/vnd.ms-excel");
			//multipart.addHeaderField("Content-Type","application/pdf");
			//multipart.addFormField("description", "Cool Pictures");
			//multipart.addFormField("keywords", "Java,upload,Spring");

			multipart.addFilePart("file", uploadFile);
			// multipart.addFilePart("fileUpload", uploadFile2);

			List<String> response = multipart.finish();
			System.out.println("Invoking sucess. Awaiting status");
			System.out.println("SERVER REPLIED:");


			for (String line : response) {
				System.out.println(line);
				if (line.contains("404"))
            	{
            	System.out.println("404 Found. Retrying service");
            	setinvoice(WIT_ID, Customer_ID);
            	}
			}
		} catch (IOException ex) {
			System.out.println(ex.toString());
			System.out.println("404 Found. Retrying service");
			setinvoice(WIT_ID, Customer_ID);
			
		}
	}

	@Test(dataProvider="WIT_INFO", priority=3,enabled=true)
	public static void getfacilitydetails(String WIT_ID, String Customer_ID) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException, InterruptedException {

		//Thread.sleep(5000);
		System.out.println("Invoking service getFacilityDetails");
		String servicepath = configdataFetcher.configData("getfacilityid");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		url.setRequestMethod("GET");
		url.setRequestProperty("Authorization", configdataFetcher.configData("RPA_token"));  
		url.setRequestProperty("witId", WIT_ID);
		System.out.println("Invoking Sucess. Awaiting status");
		//Thread.sleep(5000);
		int n = url.getResponseCode();

		System.out.println("Response code for Service:"+n);

		if(n==404) {
			System.out.println("404 found. Retrying a service");
			getfacilitydetails(WIT_ID, Customer_ID);
			
		}

		if(n==200)
		{

		System.out.println("Facility ID found"+ url.getResponseMessage());


		}

		Assert.assertEquals(n, 200);
	}

	@Test(priority=4,enabled=true,dataProvider="WIT_INFO")

	public static void adddocument_razor1(String WIT_ID, String Customer_ID) throws KeyManagementException, NoSuchAlgorithmException, JSONException, InterruptedException {

		//Thread.sleep(5000);
		String charset = "UTF-8";
		System.out.println("Invoking service Add-Document: Uploading Razor screenshot");
		//File uploadFile = new File("C:\\NotBackedUp\\RPA_Files\\SCF_infoview.xlsx");
		File uploadFile = new File("C:\\NotBackedUp\\RPA_Files\\"+Customer_ID+"_RAZOR_1.png");

		String requestURL = configdataFetcher.configData("add_doc");
		//String requestURL2 = "https://mlaas-scf-services-document-mlaas-sit-scf.apps.cpaas.service.test/usecase/scf/document/addDocument";

		try {
			MultipartUtility multipart = new MultipartUtility(requestURL, charset, uploadFile, WIT_ID);

			multipart.addHeaderField("User-Agent", "CodeJava");
			System.out.println("WIT NUMBER FOUND FROM EXCEL PARSER"+WIT_ID);
			multipart.addHeaderField("refWitNo", "39044748");
			multipart.addHeaderField("AvailableLimit","150000000");
			multipart.addHeaderField("Authoriztion", configdataFetcher.configData("RPA_token"));
			//multipart.addHeaderField("Content-Type","application/vnd.ms-excel");
			multipart.addHeaderField("Content-Type","application/image");
			//multipart.addFormField("description", "Cool Pictures");
			//multipart.addFormField("keywords", "Java,upload,Spring");

			multipart.addFilePart("file", uploadFile);
			// multipart.addFilePart("fileUpload", uploadFile2);

			List<String> response = multipart.finish();
			System.out.println("Invoking sucess: waiting for status");
			System.out.println("SERVER REPLIED:");

			for (String line : response) {
				System.out.println(line);
				if (line.contains("404"))
            	{
            	System.out.println("404 Found. Retrying service");
            	adddocument_razor1(WIT_ID, Customer_ID);
            	}
			}
		} catch (IOException ex) {
			System.out.println(ex.toString());
			System.out.println("404 Found. Retrying service");
			adddocument_razor1(WIT_ID, Customer_ID);
		}
	}

	
	@Test(dataProvider="SKIP_OCR", enabled=true, priority=5)
	//@Test
	public static void isdocdownloadrequired(String CUSTOMER_ID, String DOCUMENT_TYPE, String WIT_ID) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException, InterruptedException {
		
		
		System.out.println("Passing WIT_ID's from Excel sheet");
		String servicepath = configdataFetcher.configData("IsdocdownloadRequired");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("POST");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("RPA_token"));          
	       
	        url.setRequestProperty("Content-Type", "application/json; utf-8");
	        url.setDoOutput(true);
	        
	        OutputStream os = url.getOutputStream();
	        OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");    
	        osw.write("{ \r\n\"custId\": \""
	        		+CUSTOMER_ID
	        		+"\",\r\n\"versionDate\": \"01/01/2020\", \r\n\"docTypeName\": \""
	        		+DOCUMENT_TYPE
	        		+"\"\r\n}");
	        osw.flush();
	        osw.close();
	        os.close(); 
	        
	       
	        int n = url.getResponseCode();
	        System.out.println("Response Code found for service"+n);
	       if(n==200)
	        {
	         
	    	   StringBuffer response = Baseclass.bufferedreading(url);
	         //print in String
	        System.out.println(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        System.out.println("Results after Reading JSON Response");
	        System.out.println(myResponse);
	       
	       System.out.println("isDocDownloadRequired- "+myResponse.getString("isDocDownloadRequired"));
	        System.out.println("custId- "+myResponse.getString("custId"));
	        
	        String myresponsestring = myResponse.getString("isDocDownloadRequired");
	        System.out.println("ISdowclowand response" +myresponsestring);
	        
	        
	        if(myresponsestring.equalsIgnoreCase("yes"))
	        {
	        	System.out.println("Reached Isdocdownload yes block ... continuing with regular flow");
	        	String message = "Completed";
	        	adddocument_ded(WIT_ID, CUSTOMER_ID); 
	        	adddocument_claa(WIT_ID, CUSTOMER_ID);
	        	getUpdatedoc(WIT_ID, CUSTOMER_ID, message);
	        }
	        
	        else 
	        {
	        	System.out.println("Reached Isdocdownload no block ... continuing SKIP OCR FLOW");
	        	String message = "Doc Download Not Required";
	        	
	        	getUpdatedoc(WIT_ID, CUSTOMER_ID, message);
	        }
		
	}
	             	
	        Assert.assertEquals(n, 200);
	}


	//@Test(priority=6,enabled=true,dataProvider="WIT_INFO")

	public static void adddocument_ded(String WIT_ID, String Customer_ID) throws KeyManagementException, NoSuchAlgorithmException, JSONException, InterruptedException {
		//Thread.sleep(5000);
		String charset = "UTF-8";
		//File uploadFile = new File("C:\\NotBackedUp\\RPA_Files\\SCF_infoview.xlsx");
		System.out.println("Invoking service Add-Document: Uploading DED");
		File uploadFile = new File("C:\\NotBackedUp\\RPA_Files\\"+Customer_ID+"_CPIDED_1.pdf");

		String requestURL = configdataFetcher.configData("add_doc");
		//String requestURL2 = "https://mlaas-scf-services-document-mlaas-sit-scf.apps.cpaas.service.test/usecase/scf/document/addDocument";

		try {
			MultipartUtility multipart = new MultipartUtility(requestURL, charset, uploadFile, WIT_ID);

			multipart.addHeaderField("User-Agent", "CodeJava");
			multipart.addHeaderField("Authoriztion", configdataFetcher.configData("RPA_token"));
			System.out.println("WIT NUMBER FOUND FROM EXCEL PARSER: "+WIT_ID);
			multipart.addHeaderField("refWitNo", WIT_ID);
			//multipart.addHeaderField("Content-Type","application/vnd.ms-excel");
			multipart.addHeaderField("Content-Type","application/pdf");
			
			
			//multipart.addFormField("description", "Cool Pictures");
			//multipart.addFormField("keywords", "Java,upload,Spring");

			multipart.addFilePart("file", uploadFile);
			// multipart.addFilePart("fileUpload", uploadFile2);
			System.out.println("Invoking sucess: waiting for status");
			List<String> response = multipart.finish();

			System.out.println("SERVER REPLIED:");

			for (String line : response) {
				System.out.println(line);
				if (line.contains("404"))
            	{
            	System.out.println("404 Found. Retrying service");
            	String message = "Dod Download Completed";
            	adddocument_razor1(WIT_ID, Customer_ID);
            	
            	
            	}
			}
		} catch (IOException ex) {
			System.out.println(ex.toString());
			System.out.println("404 Found. Retrying service");
			adddocument_razor1(WIT_ID, Customer_ID);
		}
	}

	//@Test(priority=7,enabled=true, dataProvider="WIT_INFO")

	public static void adddocument_claa(String WIT_ID, String Customer_ID) throws KeyManagementException, NoSuchAlgorithmException, JSONException, InterruptedException {

		//Thread.sleep(5000);
		String charset = "UTF-8";
		System.out.println("Invoking service Add-Document: Uploading CLAA");
		//File uploadFile = new File("C:\\NotBackedUp\\RPA_Files\\SCF_infoview.xlsx");
		
		File uploadFile = new File("C:\\NotBackedUp\\RPA_Files\\"+Customer_ID+"_CLAA_1.pdf");

		String requestURL = configdataFetcher.configData("add_doc");
		//String requestURL2 = "https://mlaas-scf-services-document-mlaas-sit-scf.apps.cpaas.service.test/usecase/scf/document/addDocument";

		try {
			MultipartUtility multipart = new MultipartUtility(requestURL, charset, uploadFile, WIT_ID);

			multipart.addHeaderField("User-Agent", "CodeJava");
			multipart.addHeaderField("Authoriztion", configdataFetcher.configData("RPA_token"));
			System.out.println("WIT NUMBER FOUND FROM EXCEL PARSER"+WIT_ID);
			multipart.addHeaderField("refWitNo", WIT_ID);
			//multipart.addHeaderField("Content-Type","application/vnd.ms-excel");
			multipart.addHeaderField("Content-Type","application/pdf");
			//multipart.addFormField("description", "Cool Pictures");
			//multipart.addFormField("keywords", "Java,upload,Spring");

			multipart.addFilePart("file", uploadFile);
			// multipart.addFilePart("fileUpload", uploadFile2);

			List<String> response = multipart.finish();
			System.out.println("Invoking sucess: waiting for status");
			System.out.println("SERVER REPLIED:");

			for (String line : response) {
				System.out.println(line);
				if (line.contains("404"))
            	{
            	System.out.println("404 Found. Retrying service");
            	adddocument_razor1(WIT_ID, Customer_ID);
            	}
			}
		} catch (IOException ex) {
			System.out.println(ex.toString());
			System.out.println("404 Found. Retrying service");
			adddocument_razor1(WIT_ID, Customer_ID);
		}
	}

	/*@Test(priority=8,enabled=true,dataProvider="WIT_INFO")

	public static void adddocument_razor(String WIT_ID, String Customer_ID) throws KeyManagementException, NoSuchAlgorithmException, JSONException, InterruptedException {

		//Thread.sleep(5000);
		String charset = "UTF-8";
		System.out.println("Invoking service Add-Document: Uploading Razor screenshot");
		//File uploadFile = new File("C:\\NotBackedUp\\RPA_Files\\SCF_infoview.xlsx");
		File uploadFile = new File("C:\\NotBackedUp\\RPA_Files\\"+Customer_ID+"_RAZOR_1.png");

		String requestURL = configdataFetcher.configData("add_doc");
		//String requestURL2 = "https://mlaas-scf-services-document-mlaas-sit-scf.apps.cpaas.service.test/usecase/scf/document/addDocument";

		try {
			MultipartUtility multipart = new MultipartUtility(requestURL, charset, uploadFile, WIT_ID);

			multipart.addHeaderField("User-Agent", "CodeJava");
			System.out.println("WIT NUMBER FOUND FROM EXCEL PARSER"+WIT_ID);
			multipart.addHeaderField("refWitNo", "39044748");
			multipart.addHeaderField("AvailableLimit","150000000");
			multipart.addHeaderField("Authoriztion", configdataFetcher.configData("RPA_token"));
			//multipart.addHeaderField("Content-Type","application/vnd.ms-excel");
			multipart.addHeaderField("Content-Type","application/image");
			//multipart.addFormField("description", "Cool Pictures");
			//multipart.addFormField("keywords", "Java,upload,Spring");

			multipart.addFilePart("file", uploadFile);
			// multipart.addFilePart("fileUpload", uploadFile2);

			List<String> response = multipart.finish();
			System.out.println("Invoking sucess: waiting for status");
			System.out.println("SERVER REPLIED:");

			for (String line : response) {
				System.out.println(line);
				if (line.contains("404"))
            	{
            	System.out.println("404 Found. Retrying service");
            	adddocument_razor1(WIT_ID, Customer_ID);
            	}
			}
		} catch (IOException ex) {
			System.out.println(ex.toString());
			System.out.println("404 Found. Retrying service");
			adddocument_razor1(WIT_ID, Customer_ID);
		}
	}*/

	//@Test (description="Validate Service updateDocStatus", enabled=true, dataProvider="WIT_INFO", priority=9)

	public static void getUpdatedoc(String WIT_ID, String Customer_ID, String message) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException, InterruptedException {

		//Thread.sleep(10000);
		String servicepath = configdataFetcher.configData("update_doc");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		url.setRequestMethod("POST");
		url.setRequestProperty("Authorization", configdataFetcher.configData("RPA_token"));
		url.setRequestProperty("Content-Type", "application/json; utf-8");
		url.setDoOutput(true);

		OutputStream os = url.getOutputStream();
		OutputStreamWriter osw = new OutputStreamWriter(os, "UTF-8");    
		osw.write("{\"witId\":\""
				+ WIT_ID
				//+ "\",\"status\":\"Doc Download Not Required\",\"totalNoOfDocs\":\"0\",\"statusMsg\":\"Successful\"}");
				+ "\",\"status\":\""
				+ message
				+ "\",\"totalNoOfDocs\":\"2\",\"statusMsg\":\"Successful\"}");
		osw.flush();
		osw.close();
		os.close(); 
		//Thread.sleep(5000);
		System.out.println("Invoking sucess: waiting for status");
		int n = url.getResponseCode();
		System.out.println("Response Code found for service"+n);
		if(n==404) {
			getUpdatedoc(WIT_ID, Customer_ID, message);
			System.out.println("404 found. Retrying a service");
		}
		if(n==200)
		{

			StringBuffer response = Baseclass.bufferedreading(url);
			//print in String
			System.out.println(response.toString());
			//Read JSON response and print
			JSONObject myResponse = new JSONObject(response.toString());
			System.out.println("Results after Reading JSON Response");
			System.out.println(myResponse.toString());

		}
		Assert.assertEquals(n, 200);

	}

}
