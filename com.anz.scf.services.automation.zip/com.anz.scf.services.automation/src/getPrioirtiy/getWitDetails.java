package getPrioirtiy;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.HttpsURLConnection;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import binaries.Baseclass;
import binaries.Datafetcher;
import binaries.configdataFetcher;

public class getWitDetails {

	static configdataFetcher configdata;
	
	@DataProvider(name = "WIT_INFO", parallel = true)
	public Object[][] OrderAccountPagination() {
		String testDataPath = System.getProperty("user.dir")+"\\src\\binaries\\wit_details.xlsx";
		String sheetName = "Sheet1";
		return new Datafetcher(testDataPath).getDataFromXlsxtbySheetName(sheetName);
	}

	
	
	@Test(dataProvider="WIT_INFO")
public static void getInvoice(String WIT_ID) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		
		Reporter.log("Passing WIT_ID's from Excel sheet");
		String servicepath = configdataFetcher.configData("wit_entities_valid")+WIT_ID;
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("UI_token"));        
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	       {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");      
	        //Reporter.log("isMakerStarted- "+myResponse.getString("module"));
	        //Reporter.log("WitId- "+myResponse.getString("WitId"));
	       // Reporter.log("userId- "+myResponse.getString("userId"));           
	       
		
		
		
	}
	             	
	        Assert.assertEquals(n, 200);
	}
}