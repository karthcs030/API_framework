package getPrioirtiy;

import java.awt.PageAttributes.MediaType;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.HttpsURLConnection;

//import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.testng.annotations.Test;

import binaries.Baseclass;
import binaries.Datafetcher;
import binaries.configdataFetcher;
import io.restassured.response.Response;
import sun.net.www.protocol.http.HttpURLConnection;

public class generatecodesnippet {

	
	@Test
	public static void getpostmandetails() throws IOException, KeyManagementException, NoSuchAlgorithmException, JSONException
	{
		// Connect to the web server endpoint
		String servicepath = configdataFetcher.configData("invoke_infoview");
		HttpsURLConnection urlconnection = Baseclass.bypassSSL(servicepath);
		 
		String boundaryString = "----WIT";
		String fileUrl = "C:\\NotBackedUp\\SCF_Framework\\framework\\src\\test\\resources\\binaries\\Work_Group_Open_Items_-_SCF100.xlsx";
		File logFileToUpload = new File(fileUrl);
		String s = logFileToUpload.getName();
		System.out.println(s);
		
		 
		// Indicate that we want to write to the HTTP request body
		urlconnection.setDoInput(true);
		urlconnection.setDoOutput(true);
		urlconnection.setUseCaches(false);
		urlconnection.setRequestMethod("POST");
		urlconnection.setRequestProperty("Authorization", "Bearer Welcome1");
		urlconnection.addRequestProperty("file", "multipart/form-data; boundary=" + boundaryString);
		//urlconnection.addRequestProperty("Content-Type", "application/vnd.ms-excel\r\n\r\n");
		urlconnection.addRequestProperty("file", logFileToUpload.getName());
	
		 
		OutputStream outputStreamToRequestBody = urlconnection.getOutputStream();
		BufferedWriter httpRequestBodyWriter =
		    new BufferedWriter(new OutputStreamWriter(outputStreamToRequestBody));
		 
		// Include value from the myFileDescription text area in the post data
		httpRequestBodyWriter.write("\r\n\r\n--" + boundaryString + "\r\n");
		//httpRequestBodyWriter.write("Content-Disposition: form-data; name=\"binayFile\"");
		httpRequestBodyWriter.write("\r\n\r\n");
		//httpRequestBodyWriter.write("Log file for 20150208");
		 
		// Include the section to describe the file
		httpRequestBodyWriter.write("\r\n--" + boundaryString + "\r\n");
		httpRequestBodyWriter.write("Content-Disposition: form-data;"
				+ "name=\""
		        + "file=\""+ logFileToUpload.getName() +"\""
		        + "\r\nContent-Type: application/vnd.ms-excel\r\n\r\n");
		httpRequestBodyWriter.flush();
		 
		// Write the actual file contents
		@SuppressWarnings("resource")
		FileInputStream inputStreamToLogFile = new FileInputStream(logFileToUpload);
		 
		int bytesRead;
		byte[] dataBuffer = new byte[4096];
		while((bytesRead = inputStreamToLogFile.read(dataBuffer)) != -1) {
		    outputStreamToRequestBody.write(dataBuffer, 0, bytesRead);
		}
		 
		outputStreamToRequestBody.flush();
		 
		// Mark the end of the multipart http request
		httpRequestBodyWriter.write("\r\n--" + boundaryString + "--\r\n");
		httpRequestBodyWriter.flush();
		 
		// Close the streams
		outputStreamToRequestBody.close();
		httpRequestBodyWriter.close();
		Object n = urlconnection.getResponseCode();
		System.out.println(n);
	
	
	// Read response from web server, which will trigger the multipart HTTP request to be sent.
	/*BufferedReader httpResponseReader =
	    new BufferedReader(new InputStreamReader(urlconnection.getInputStream()));
	String lineRead;
	while((lineRead = httpResponseReader.readLine()) != null) {
	    System.out.println(lineRead);*/
	}
	
	
}
//}
