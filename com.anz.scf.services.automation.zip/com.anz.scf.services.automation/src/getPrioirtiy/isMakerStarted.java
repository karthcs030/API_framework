package getPrioirtiy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.apache.tika.mime.MediaType;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import binaries.Baseclass;
import binaries.Datafetcher;
import binaries.configdataFetcher;
import io.restassured.internal.util.IOUtils;

public class isMakerStarted {

	static configdataFetcher configdata;
	
	@DataProvider(name = "WIT_INFO", parallel = true)
	public Object[][] OrderAccountPagination() {
		String testDataPath = System.getProperty("user.dir")+"\\src\\binaries\\wit_details.xlsx";
		String sheetName = "Sheet1";
		return new Datafetcher(testDataPath).getDataFromXlsxtbySheetName(sheetName);
	}

	
	
	@Test(dataProvider="WIT_INFO")
	public static void isMakerStarted(String WIT_ID) throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		
		Reporter.log("Passing WIT_ID's from Excel sheet");
		String servicepath = configdataFetcher.configData("emptyurl_ismaker")+WIT_ID;
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("UI_token"));        
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	       {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");      
	        Reporter.log("isMakerStarted- "+myResponse.getString("isMakerStarted"));
	        Reporter.log("WitId- "+myResponse.getString("WitId"));
	       // Reporter.log("userId- "+myResponse.getString("userId"));           
	       
		
		
		
	}
	             	
	        Assert.assertEquals(n, 200);
	}

	@Test
	public static void isMakerStarted_ten() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		Reporter.log("Passing 18 digits a WIT_num");
		String servicepath = configdataFetcher.configData("ismakerStarter_withmaxlength");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("UI_token"));       
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	       {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");      
	        Reporter.log("isMakerStarted- "+myResponse.getString("isMakerStarted"));
	        Reporter.log("WitId- "+myResponse.getString("WitId"));
	       // Reporter.log("userId- "+myResponse.getString("userId"));           
	       
		
		
		
	}
	             	
	        Assert.assertEquals(n, 200);
	}


	@Test
	public static void isMakerStarted_null() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		Reporter.log("Passing empty string as a WIT ID");
		String servicepath = configdataFetcher.configData("ismakerstarted_null");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("UI_token"));         
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==400)
	       {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");      
	        Reporter.log("isMakerStarted- "+myResponse.getString("isMakerStarted"));
	        Reporter.log("WitId- "+myResponse.getString("WitId"));
	        Reporter.log("userId- "+myResponse.getString("userId"));           
	       
		
		
		
	}
	             	
	        Assert.assertEquals(n, 400);
	        Reporter.log("Bad Request !! Request parameter missing!!");
	}



	@Test
	public static void isMakerStarted_valid() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		Reporter.log("Passing inValid WIT_ID as a parameter");
		String servicepath = configdataFetcher.configData("ismakerstarted_valid");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("UI_token"));
	       // url.setRequestProperty("Content-Type", "application/json; utf-8");
	       // url.setDoOutput(true);       
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	       {
	         

	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");      
	        Reporter.log("isMakerStarted- "+myResponse.getString("isMakerStarted"));
	        Reporter.log("WitId- "+myResponse.getString("WitId"));
	       // Reporter.log("userId- "+myResponse.getString("userId"));           
	       
		
		
		
	}
	             	
	        Assert.assertEquals(n, 200);
	}

	@Test
	public static void isMakerStarted_zero() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		Reporter.log("Passing a WIT ID which starts from 0");
		String servicepath = configdataFetcher.configData("ismakerStarter_withstartzero");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("UI_token"));
	       // url.setRequestProperty("Content-Type", "application/json; utf-8");
	       // url.setDoOutput(true);       
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	       {
	         

	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");      
	        Reporter.log("isMakerStarted- "+myResponse.getString("isMakerStarted"));
	        Reporter.log("WitId- "+myResponse.getString("WitId"));
	       // Reporter.log("userId- "+myResponse.getString("userId"));           
	       
		
		
		
	}
	             	
	        Assert.assertEquals(n, 200);
	}
	
	@Test
	public static void isMakerStarted_min() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		Reporter.log("Passing MIN digits for WIT_ID");
		String servicepath = configdataFetcher.configData("ismakerStarter_2");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("UI_token"));
	       // url.setRequestProperty("Content-Type", "application/json; utf-8");
	       // url.setDoOutput(true);       
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	       {
	         

	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");      
	        Reporter.log("isMakerStarted- "+myResponse.getString("isMakerStarted"));
	        Reporter.log("WitId- "+myResponse.getString("WitId"));
	       // Reporter.log("userId- "+myResponse.getString("userId"));           
	       
		
		
		
	}
	             	
	        Assert.assertEquals(n, 200);
	}
	
	
	@Test
	public static void isMakerStarted_special() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		Reporter.log("Passing Special characters inside WIT_number");
		String servicepath = configdataFetcher.configData("ismkaerStarted_special");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("UI_token"));          
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	       {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");      
	        Reporter.log("isMakerStarted- "+myResponse.getString("isMakerStarted"));
	        Reporter.log("WitId- "+myResponse.getString("WitId"));
	        Reporter.log("userId- "+myResponse.getString("userId"));           
	       
		
		
		
	}
	             	
	        Assert.assertEquals(n, 200);
	}
	

	@Test
	public static void isMakerStarted_string() throws KeyManagementException, NoSuchAlgorithmException, IOException, JSONException {
		
		Reporter.log("Passing String as WIT_ID");
		String servicepath = configdataFetcher.configData("ismkaerStarted_string");
		HttpsURLConnection url = Baseclass.bypassSSL(servicepath);
		 url.setRequestMethod("GET");
		 url.setRequestProperty("Authorization", configdataFetcher.configData("UI_token"));          
	       
	        int n = url.getResponseCode();
	        Reporter.log("Response code for Service:"+n);
	        if(n==200)
	       {
	         
	        	StringBuffer response = Baseclass.bufferedreading(url);
	         //print entire service response in String
	        Reporter.log(response.toString());
	         //Read JSON response and print
	         JSONObject myResponse = new JSONObject(response.toString());
	        Reporter.log("Results after Reading JSON Response");      
	        Reporter.log("isMakerStarted- "+myResponse.getString("isMakerStarted"));
	        Reporter.log("WitId- "+myResponse.getString("WitId"));
	        Reporter.log("userId- "+myResponse.getString("userId"));           
	       
		
		
		
	}
	             	
	        Assert.assertEquals(n, 200);
	}
	

}
